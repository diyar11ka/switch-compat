package com.on1k.switchcompat

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.SearchView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.on1k.switchcompat.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    lateinit var listView1: ListView
    lateinit var listView2: ListView
    private var currentListViewIndex = 0
    private val selectedData = mutableListOf<String>()
    private lateinit var adapter1: ArrayAdapter<String>
    private var extraListViewStates = booleanArrayOf(false, false, false)


    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        binding.geridonBTN.setOnClickListener {
           // Where ever u wanna go back to
        }
        listView1 = binding.listview
        listView2 = binding.listview2
        val exercises = arrayOf(
            "Barbell Curl",
            "Hammer Curl",
            "Dumbbell Curl",
            // Add more exercises as needed
        )

        adapter1 = ArrayAdapter(this, android.R.layout.simple_list_item_1, exercises)
        listView1.adapter = adapter1

        val adapter2 = ArrayAdapter(this, android.R.layout.simple_list_item_1, selectedData)
        listView2.adapter = adapter2

        listView1.setOnItemClickListener { parent, view, position, id ->

            val selectedItem = exercises[position]
            if (!selectedData.contains(selectedItem)) {
                selectedData.add(selectedItem)
                adapter2.notifyDataSetChanged()
            }

        }

        listView2.setOnItemClickListener { parent, view, position, id ->
            selectedData.removeAt(position)
            adapter2.notifyDataSetChanged()
        }
        binding.kaydetBTN.setOnClickListener {
            transferData()
            (binding.listview2.adapter as? ArrayAdapter<*>)?.clear()
        }

        binding.switch1.isChecked = true
        toggleListViews(binding.switch1.isChecked)
        binding.switch1.setOnCheckedChangeListener { _, isChecked ->
            toggleListViews(isChecked)
        }
        binding.goruntule1BTN.setOnClickListener {
            if (binding.gun1.visibility == View.GONE) {
                binding.gun1.visibility = View.VISIBLE
            } else {
                binding.gun1.visibility = View.GONE
            }
        }
        binding.goruntule2BTN.setOnClickListener {
            if (binding.gun2.visibility == View.GONE) {
                binding.gun2.visibility = View.VISIBLE
            } else {
                binding.gun2.visibility = View.GONE
            }
        }
        binding.goruntule3BTN.setOnClickListener {
            if (binding.gun3.visibility == View.GONE) {
                binding.gun3.visibility = View.VISIBLE
            } else {
                binding.gun3.visibility = View.GONE
            }
        }
        binding.temizle1BTN.setOnClickListener {
            clearListView(binding.listview3, binding.temizle1BTN, 0)
        }
        binding.temizle2BTN.setOnClickListener {
            clearListView(binding.listview4, binding.temizle2BTN, 1)
        }
        binding.temizle3BTN.setOnClickListener {
            clearListView(binding.listview5, binding.temizle3BTN, 2)
        }

        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                adapter1.filter.filter(newText)
                return false
            }
        })

    }

    private fun toggleListViews(show: Boolean) {
        if (show) {
            binding.antekle.visibility = View.VISIBLE
            binding.antlarim.visibility = View.GONE
        } else {
            binding.antlarim.visibility = View.VISIBLE
            binding.antekle.visibility = View.GONE
        }

    }

    private fun transferData() {
        val targetIndex = extraListViewStates.indexOf(false)
        if (targetIndex == -1) {
            Toast.makeText(this, "Maksimum 3 program oluşturabilirsiniz.", Toast.LENGTH_SHORT).show()
            return
        }
        when (targetIndex) {
            0 -> {
                binding.listview3.visibility = ListView.VISIBLE
                binding.listview3.adapter =
                    ArrayAdapter(this, android.R.layout.simple_list_item_1, selectedData.toList())
            }

            1 -> {
                binding.listview4.visibility = ListView.VISIBLE
                binding.listview4.adapter =
                    ArrayAdapter(this, android.R.layout.simple_list_item_1, selectedData.toList())
            }

            2 -> {
                binding.listview5.visibility = ListView.VISIBLE
                binding.listview5.adapter =
                    ArrayAdapter(this, android.R.layout.simple_list_item_1, selectedData.toList())
            }

            else -> {
                Toast.makeText(this, "Maksimum 3 program oluşturabilirsiniz.", Toast.LENGTH_SHORT).show()
                return
            }
        }
        extraListViewStates[targetIndex] = true
        currentListViewIndex++
    }
    private fun clearListView(listView: ListView, button: Button, index: Int) {
        (listView.adapter as? ArrayAdapter<*>)?.clear()
        extraListViewStates[index] = false

        if (currentListViewIndex > index) {
            currentListViewIndex = index
        }
    }
}